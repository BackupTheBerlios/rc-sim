import fnmatch
import os


def compareNames(name):

 s="FileSystem="
 
 for root, dirs, files in os.walk(name):
     for dir1 in dirs:
	filepath=os.path.join(root, dir1)
	print s+filepath

compareNames("/home/gabdab/Desktop/8-12/2-11-models/q3/mod/textures/")
