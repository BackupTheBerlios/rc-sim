#!BPY

#def readTexture(rootPath):
import fnmatch
import os

#def split_dir_base_ext(path):
import glob, os, string, sys, optparse

from Blender import Mesh, Scene, Window, sys, Image, Draw
import BPyMesh
import BPyObject
import BPySys
import BPyMessages

from Blender import Mesh, Material, Curve, Metaball
from Blender import *
import Blender
import bpy
from Blender import Texture

scn = Blender.Scene.GetCurrent()
objects = Blender.Object.Get()
for ob_main in objects:
 if ob_main.type =='Mesh':
  print ob_main
  editmode = Window.EditMode()    # are we in edit mode?  If so ...
  if editmode: Window.EditMode(0) # leave edit mode before getting the mesh
  me = ob_main.getData(mesh=1)
  if me is not None:
   print me
   mm=me.materials
   if mm is not None:
    for m in mm:
     print m.name
"""
     name=Material.Get(m.name) 
     textures = name.getTextures() 
     for mtex in textures:
        if not ( mtex == None ):
            texture = mtex.tex
            if ( texture.type == Blender.Texture.Types.IMAGE ):
	      print texture.image
	    else:
             print "Nessuna Texture"
	     break
"""
	     
"""
     mt1=mtextures[0]
     if mt1 != None:
       if mt1.tex.image!='None':
	print mt1.tex.image 
       else:
        print "NULLA"
"""
"""
     if mtextures is not None:
       for mtex in mtextures[:]:
        if mtex != None:
         if mtex.tex.type == Texture.Types.IMAGE: 
          print mtex.tex.image 
"""    

"""
     mesh = NMesh.GetRawFromObject(ob_main.name)
     ObjName = mesh.name
     if mesh.hasFaceUV():
 	if mesh.FaceModes=='TEX':
         print "true"
        else:
         print "false"
     
"""
