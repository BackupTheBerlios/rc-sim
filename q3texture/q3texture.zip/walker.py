
#!BPY

#def readTexture(rootPath):
import fnmatch
import os

#def split_dir_base_ext(path):
import glob, os, string, sys, optparse

from Blender import Mesh, Scene, Window, sys, Image, Draw
import BPyMesh
import BPyObject
import BPySys
import BPyMessages

from Blender import Mesh, Material, Curve, Metaball
from Blender import *
import Blender
import bpy
from Blender import Texture

rootPath = '/home/gabdab/Desktop/8-12/2-11-models/q3/mod/textures/'
#name = '*.mp3' # Can include any UNIX shell-style wildcards
name=''
filename=''
filepath=''

def readTexture(rootPath):
 #scn = Blender.Scene.GetCurrent()
 for root, dirs, files in os.walk(rootPath):
     for filename in files:
        if fnmatch.fnmatch(filename, name):
             print os.path.join(root, filename)



def obMat():

 global name
 global me

 objects = Blender.Object.GetSelected()
 for ob_main in objects:
  for ob, ob_mat in BPyObject.getDerivedObjects(ob_main):
   # Will work for non meshes now! :)
   me=BPyMesh.getMeshFromObject(ob, container_mesh=None, apply_modifiers=True, vgroups=True, scn=None)
			#me= BPyMesh.getMeshFromObject(ob, containerMesh, EXPORT_APPLY_MODIFIERS, False, scn)				
  #for obj in objects:
   materials = me.materials		
   materialNames = []
   materialItems = materials[:]
   if materials:
    for mat in materials:
     if mat: # !=None
      #materialNames.append(mat.name)
      print mat.name
      name=mat.name


def split_dir_base_ext(path):
    """Split a path into a 3-tuple containing dirname, filename sans
    extension, and extension.
    >>> split_dir_base_ext('/foo/bar/biz.txt')
    ('/foo/bar', 'biz', '.txt')
    >>> split_dir_base_ext('.txt')
    ('', '', '.txt')
    """
    dn = os.path.dirname(path)
    name, ext = os.path.splitext(os.path.basename(path))
    return dn, name, ext


def compareNames(rootPath):

 global filename
 global filepath
 for root, dirs, files in os.walk(rootPath):
     for filename1 in files:
	name1, ext = os.path.splitext(os.path.basename(filename1))
	if fnmatch.fnmatch(name1, name):
             print os.path.join(root, filename1)
	     filepath=os.path.join(root, filename1)
	     filename=filename1
	     print filename


def applyMaterial():
  global filepath
  #global me
  global filename
  global name

  print filepath
  #print me
  print filename

  scn = Blender.Scene.GetCurrent()
  objects = Blender.Object.GetSelected()
  for ob_main in objects:
   #me = mb0.getData(False,True) 
   me = ob_main.getData(mesh=1)
   print me
   img=Blender.Image.Load(filepath)
   img1 = bpy.data.images[filename]
   for fc in me.faces: fc.image = img1
   footex = Texture.New(filename)             # get texture named 'foo'
   footex.setType('Image')                 # make foo be an image texture
   footex.image = img                      # link the image to the texture
   name=Material.Get(name)               # get a material
   name.setTexture(0, footex)               # set the material's

   mtextures = name.getTextures()           # get a list of the

   for mtex in mtextures:
     if mtex is not None:
      if mtex.tex.type == Texture.Types.IMAGE: 
       print mtex.tex.image.filename   
       mtex.texco = Blender.Texture.TexCo['UV']
       mtex.mapto = Blender.Texture.MapTo['COL']
   else:
     print name

     

obMat()
compareNames(rootPath)
applyMaterial()

     
	     
"""
def main():
	#Blender.Window.FileSelector(readTexture, 'Import skin ', '*.skin')
	#read_glm("/home/gabdab/Desktop/jk_18_9/vehicles/models/players/droid_fighter/model_default.skin")
	#readTexture(rootPath)
	#obMat()
	readTexture(rootPath)

if __name__ == '__main__':
	#def foo():
	main()
"""
