#!/usr/bin/env python
import os
# with os.path
DIR = 'ogre'
num=0
s="   	    SceneNode *mNode;\
            Entity *mEntity;\
	    mNode = mSceneMgr->getRootSceneNode ()->createChildSceneNode ();"
print s
for f in os.listdir(DIR):
    if f.endswith('.mesh'):
      #print "file ", f
      num+=1
      #print num
      t="mEntity = mSceneMgr->createEntity ("+"\""+f+"\""+", "+"\""+f +"\""+");\
	    mNode->attachObject (mEntity);"
      print t
     # s="ffmpeg -i"+" "+f+" "+"-ab 128 -b 1200 -vcodec mpeg4"+" "+ f+".avi"""
     # cmd = s
     # status = os.system(cmd)
     # print "Status: ", status
    

